#include <stdio.h>

int main() {
    int principal, rate, years;
    scanf("%d", &principal);
    scanf("%d", &rate);
    scanf("%d", &years);
 float interest = (principal * rate * years) / 100.0f;
 float total_amount = principal + interest;
 float discount = 0.02f * interest;
 float final_settlement = total_amount - discount;
    printf("%.2f\n", interest);
    printf("%.2f\n", total_amount);
    printf("%.2f\n", discount);
    printf("%.2f\n", final_settlement);
    return 0;
}
