#include <stdio.h>

int main() {
    
    int l=50,b=20;

    int perimeter = 2 * (l+b);
    int area = l*b;            

    printf("%d\n", perimeter);
    printf("%d\n", area);

    return 0;
}
