#include <stdio.h>

int main() {
    int a, b;
    scanf("%d", &a);
    scanf("%d", &b);

    printf("%d\n", a + b);  // Addition
    printf("%d\n", a - b);  // Subtraction
    printf("%d\n", a * b);  // Multiplication
    printf("%d\n", a % b);  // Modulo division
    printf("%d\n", a / b);  // Division (integer division)

    return 0;
}
